#include <stdio.h>
#include <ctype.h>

int main ( int argc, char *argv[] ) {
	char line[256];
	char junk[100];
	int c;
   	if ( argc != 2 ) {
        	// We print argv[0] assuming it is the program name 
		printf( "usage: %s filename", argv[0] );
    		return;
	}

        //argv[1] contains the filename to open
        FILE *file = fopen( argv[1], "r" );

        /* fopen returns 0, the NULL pointer, on failure */
        if ( file == 0 ) {
            printf( "Could not open file\n" );
        } else {
            
            /* read one character at a time from file, stopping at EOF, which
               indicates the end of the file.  Note that the idiom of "assign
               to a variable, check the value" used below works because
               the assignment statement evaluates to the value assigned. */
            /*while  ( ( x = fgetc( file )>'A' && x<'z')
            {
                printf( "%s", x );
            }*/
		fgets(line, sizeof(line), file); // discard empty line
		while (fgets(line, sizeof(line), file)) {
			char *token = strtok(line, ",");
			printf("%s ", token);
			// This will be the name
			
			int sum = 0;
			int count = 0;
			while (token) {
				token = strtok(NULL, ",");

				if (token != NULL) {

					sum += atoi(token);
				}
				count++;
			}
			
			float avg = (float) sum / ( count-1);
			printf("Avg : %.2f\n", avg);	// the %.2f is because we want the answer with only 2 decimal places 	
		}
        }
}

