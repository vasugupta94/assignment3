#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main ()
{
int inputSize=150;
char command[inputSize];
char *prompt = "[SUPER SHELL!!]";
char *p;
char *token;

char newcommand[inputSize];


while(1){

printf("%s", prompt);// prints prompt Super Shell!!
fgets(command,sizeof(command),stdin);
strcpy(newcommand, command);// copies command into new command 
//new command saves original input

int i;
for(i=0;i<inputSize;i++){
command[i]= tolower(command[i]);// so that the user can input in lower case as well- this is lower case version of the input 
}

if( strcmp(command, "quit\n") == 0) { //if quit 

exit(0);
    
}

else if( strncmp(command, "set prompt ", 11) == 0) {

p= ( newcommand+ 11 ); //move the pointer 
prompt=p;
system(newcommand);
}

else{ // if standard methods 
   system(newcommand);
}
prompt[strlen(prompt)-1] = "\0"; 
}

return 0;

}
