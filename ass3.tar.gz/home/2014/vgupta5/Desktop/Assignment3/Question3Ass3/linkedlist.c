#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define ENGLISH 
//#define FRENCH  
#define DELIM " \n"


struct NODE{
  struct NODE* next;		
        char data[500];
        };
typedef struct NODE linkedlist;	
     
char input[500];
int main(void) 
{
    linkedlist *head=NULL; 	
    linkedlist *tail=NULL;	
    linkedlist *p;		
    
    #ifdef ENGLISH
	printf("Welcome to the infinite string storage program. \n");
    #else
	printf("Bienvenue au programme de stockage de liste de mots infinie.\n");// french part may not be right
 #endif

    while(1){ // while true
    #ifdef ENGLISH
	printf("Please input a single word: \n");
    #else
	printf("Entrez un seul mot: \n");
    #endif


    fgets(input,1000,stdin);		
    char *tok = strtok(input, DELIM);  
	
    if(strcmp(tok,"***END***")==0){	//the case if the user does not input ***END***
	p=head;	
	while(p!=NULL){	
	printf("%s ",p->data);	
	p=p->next;	
    }
	printf("\n");			
	break;  			
}
else{ //if the user does input ***END***
   	     p=(linkedlist *)malloc(sizeof(linkedlist));	
          
	if(head==NULL){
		  head= p;		
		}
	     if(tok != NULL){		
		strcpy(p->data,tok);	
		}
		
	     if(tail!=NULL)	{		
	      tail->next= p;			
	     }
             tail= p;				
	}
     }
     return 0;					
}

